package javaPolymorphism;

public class Q2 {

	public static void main(String[] args) {
		Monster poly = new WaterMonster();
		Monster Jame = new FireMonster();
        System.out.println(poly.attack());
        System.out.println(Jame.attack());
	}

}
interface Monster{
	String name = "Game";
	public String attack();	
}

class FireMonster implements Monster{
	
	public String attack() {
		return "Breath fire on them";
	}
}

class WaterMonster implements Monster{
	
	public String attack() {
		return "command Water on them";
	}
}
class StoneMonster implements Monster{
	
	public String attack() {
		return "command Stone on them";
	}
}