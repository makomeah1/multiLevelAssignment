package javaPolymorphism;



public class Q1 {

	public static void main(String[] args) {
		Triangle T = new Triangle();
		T.setBase(5);
		T.setHieght(10);
		
		System.out.println("The area of the Triangle: "+T.getArea());
		
		Rectangle P = new Rectangle();
		P.setLength(5);
		P.setWidth(10);
		System.out.println("The area of the Rectangle: "+P.getArea());
		
		
	}

}
interface Shape {
	
	final String color = "Green";
	public double getArea();
	public String toString() ;	
	
}

class Rectangle implements Shape{
	private int length;
	private int width;
	
	
	public int setLength(int x) {
	return	this.length=x;
	}
	public int setWidth(int y) {
		return	this.width=y;
		}
	
	public double getArea() {
		return (length*width);	
	
	}
	
	public String toString() {
		return color + length+ width;
	
	}
}
class Triangle implements Shape{
	private int hieght;
	private int base;
	
  
  
  public int setHieght(int y) {
		return	this.hieght=y;
		}
  
  public int setBase(int y) {
		return	this.base=y;
		}
public	double getArea() {
		return 0.5* hieght*base;
	}
	
	public String toString() {
		return color + hieght+ base;
	}
}









