package multiLevel;

public class Q1 {
/*
 * Create a class named �Electronics� that provides a method device_type() for all the
electronic devices. Now create a class named �Television� which extends the Electronics
class which specifies the Electronics device and has a method name � category() to
display the type of electronic device. Then, create a class named �LED� extends the
Television class to specify the technology used for its display. It has the method
display_tech() to show the technology is LED.
 * 
 */

	public static void main(String[] args) {
		LED Vreal = new LED();
		Vreal.display_tech();
		Vreal.device_type();
		

	}

}

class Electronics{
	
	
	public String device_type(){
		
		return 	"all electronic device";
	}
}


class Television extends Electronics{
	public void category() {
		System.out.println("The type of Electronic device");
		
	}
}
class LED extends Television{
	
	public void display_tech() {
		System.out.println("The technology is LED");
	}
}






