package multiLevel;

public class Q2 {
	

	public static void main(String[] args) {
		//customer_name+" "+ account_no+ " "+ min_bal +" "+ saving_bal+ " "+  deposits +" "+ " " + withdrawals
		 Account_Details GCB = new Account_Details("Dave", "204353","$100.4","$4566",2453.23,2311.32);
		             GCB.display();
	}

}
class Account{
	 String customer_name;
	 String account_no;
	
	Account( String customer_name,String account_no){
		this. customer_name=customer_name;
		this.account_no =account_no;
	}
	
	public void display() {
		
		System.out.println(customer_name+" "+account_no);
	}	
}
class Savings_Account extends Account{
	 String min_bal;
	 String  saving_bal;
	
	 Savings_Account( String customer_name,String account_no,String min_bal,String  saving_bal){
		 super( customer_name, account_no);
		 this.min_bal=min_bal;
		 this.saving_bal=saving_bal;
	 }
	
	public void display() {
		System.out.println(customer_name +" "+ account_no + min_bal+ " "+saving_bal);
	}
	
}
/*
 * 2. Create a class named �Account� with the two properties (customer_name & account_no)
and a method named �display()� that prints its properties. Create another class named
�Saving_Account� that extends the �Account� class and inherits its properties. This class
also has two properties(min_bal & saving_bal) and a method named �display()� which
prints all four properties. Create another class named �Account_Details� which extends
the �Saving_Account� class and gathers all the properties of it. It also has two
properties(deposits & withdrawals) and a method named �display()� which prints all the
properties. Now create an object of �Account_Details� in the main class and print all the
properties of all the classes.
 * 
 */
class Account_Details extends Savings_Account{
	double deposits;
	double withdrawals;
	 Account_Details(String customer_name,String account_no,String min_bal,String  saving_bal,double deposits,double withdrawals){
		 super(customer_name, account_no, min_bal, saving_bal);
		 this.deposits=deposits;
		 this.withdrawals=withdrawals;
		 }
		 
		public void display(){
			 System.out.println("customer_name: "+ customer_name+" "+"account_no: " + account_no+ " "+"min_bal: " + min_bal +" "+
		"saving_bal: "+ saving_bal+ " "+"deposits: " + deposits +" "+ " " +"withdrawals: "+ withdrawals);
		 
		 }		
}



