package multiLevel;

public class Q3 {

	public static void main(String[] args) {
		Manager poly = new Manager();
		poly.place();
		poly.nationality();
		poly.organisation();

	}

}
class person {
	
	
	void nationality() {
		System.out.println("Ghana");
	}
	void Place() {
		System.out.println("Accra");
	}
	
}
class Emp extends person{
	
	void organisation() {
		System.out.println("Amalitech");
	
	}
	
	void Place() {
		System.out.println("Takoradi");
	}
	
}
class Manager extends Emp{
	
	void surbodinates() {
		System.out.println("Secretary");
		
	}
	
	void place() {
		
		System.out.println("Administrative Department");
	}
}



